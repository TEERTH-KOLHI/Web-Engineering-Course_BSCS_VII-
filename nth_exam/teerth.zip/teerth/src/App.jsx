
import React, { useState } from 'react';
import './App.css'

const App = () => {
  const [counters, setCounters] = useState([0, 0]);

  const handleAddCounter = () => {
    setCounters([...counters, 0]);
  };

  const handleDeleteCounter = (index) => {
    const updatedCounters = counters.filter((_, i) => i !== index);
    setCounters(updatedCounters);
  };

  const handleIncrement = (index) => {
    const updatedCounters = [...counters];
    updatedCounters[index] = Math.min(updatedCounters[index] + 1, 9);
    setCounters(updatedCounters);
  };

  const handleDecrement = (index) => {
    const updatedCounters = [...counters];
    updatedCounters[index] = Math.max(updatedCounters[index] - 1, 0);
    setCounters(updatedCounters);
  };

  return (
    <>
      <nav className='navi'>Navigation</nav>
      <div className='cont'>
        {counters.map((counter, index) => (
          <div key={index}>
            <button onClick={() => handleDecrement(index)}>-</button>
            <span>{counter}</span>
            <button onClick={() => handleIncrement(index)}>+</button>
            <button onClick={() => handleDeleteCounter(index)}>Delete</button>
          </div>
        ))}
      </div>
      <button onClick={handleAddCounter}>Add Counter</button>
      <footer className='footer'>Footer</footer>
    </>
  );
}

export default App;



