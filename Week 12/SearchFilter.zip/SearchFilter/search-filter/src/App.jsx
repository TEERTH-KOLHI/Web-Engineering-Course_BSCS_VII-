
import { useState } from 'react';
import './App.css'
import "./style.css";
import JSONDATA from "./MOCK_DATA.json";
function App() {
  const [searchTerm, setSearchTerm] = useState('')

  return (
    <div className = "app">
      <input type="text" placeholder='Search' onChange={ event => {setSearchTerm(event.target.value)}}/>
      {JSONDATA.filter((val) =>{
        if(searchTerm == ""){
          return val
        }else if(first_name.toLowerCase().includes(searchTerm.toLocaleLowerCase())){
          return val
        }
      }).map((val, key)=>{
        return ( 
        <div>
          <p>{val.first_name}</p>
        </div>
        );
      })}

    </div>
  );
}

export default App

// 1:25:37