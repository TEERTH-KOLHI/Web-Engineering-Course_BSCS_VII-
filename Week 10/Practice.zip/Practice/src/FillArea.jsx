import './FillArea.css'

function FillArea() {
    return (
      <>
      <div>
      <header className="header">Navbar</header>
        <footer className="footer">Footer</footer>
      </div>
      </>
    );
  }
  
  export default FillArea;